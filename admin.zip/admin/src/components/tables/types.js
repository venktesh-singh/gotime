const tableTypes = {
  employeesList: "employeesList",
  organizationList: "organizationList",
  payslip: "payslip",
};

export default tableTypes;
