export const LOGOUT = "LOGOUT";
export const SET_LOADER = "SET_LOADER";
