export const SET_USER_DATA = "SET_USER_DATA";
