import passwordImage from "./password.jpg";

const Images = {
  passwordImage: passwordImage
}

export default Images
