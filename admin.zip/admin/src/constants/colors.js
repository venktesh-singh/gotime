const Colors = {
  red: "#DA634A",
  borderColor: "green",
};

export default Colors;
