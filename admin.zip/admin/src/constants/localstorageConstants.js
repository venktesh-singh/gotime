const localStorageConstants = {
  userId: "userId",
};

export default localStorageConstants;
